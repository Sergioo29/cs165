/*****************************************************
 * File: lander.cpp
 * Author: Sergio Henrique
 *
 * Description: This file contains the lander class bodies.
 ******************************************************/
#include "lander.h"
#include "uiDraw.h"

void Lander :: applyGravity (float amount)
{
  // velocity
}

bool Lander :: canThrust()
{
  return (isAlive() && !isLanded() && fuel > 0); 
}

void Lander :: applyThrustLeft()
{
  // if can thrust: add to velocity
  // assert: consume fuel
}

void Lander :: applyThrustRight()
{
  // opposite to left
}

void Lander :: applyThrustBottom()
{
  // velocity
  // assert: consume fuel
}

void Lander :: advance()
{
  point.addX(1); // get direction from velocity
  point.addY(1);
}

void Lander :: draw() const
{
  if (isAlive())
  {
    drawLander(point);
  }
}
