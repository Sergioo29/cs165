/***********************************************************************
 * Header File:
 *    Velocity header.
 * Author:
 *    Sergio Henrique
 * Summary:
 *    This is the velocity header.
 ************************************************************************/
#ifndef velocity_h
#define velocity_h
#include "point.h"

class Velocity
{
private:
  float dx;
  float dy;

public:
  Velocity()
  {
    dx = 0.0;
    dy = 0.0;
  }
};


#endif
